# BCRP Data Scrapper
## Definición
Librería de python que te permite descargar data del Banco Central de Reserva del Perú (BCRP)

## Instalación

1. Importar librerias  

    <code>pip install -r requirements.txt</code>  

    <note>Nota: Recomendable realizarlo desde la consola de windws.</note>

2. Importar paquete  

    <code>pip install bcrp_data</code>  

    <note>Nota: Recomendable realizarlo desde la consola de windws.</note>